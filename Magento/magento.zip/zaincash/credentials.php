<?php
ini_set('precision', 15); 

//ENTER THESE VALUES BY YOURSELF OR USE ANOTHER VARIABLES TO LINK THEM

// ----------------- Merchant Details --------------------------
//Your wallet number   (ZainCash IT will provide it for you)
$msisdn=9647800624733;

//Secret   (ZainCash IT will provide it for you)
$secret='1zaza5a444a6e8723asd123asd123sfeasdase12312davwqf123123xc2ego';

//Merchant ID   (ZainCash IT will provide it for you)
$merchantid='57f3a0635a726a48ee912866';

//Test credentials or Production credentials (true=production , false=test)
$production_cred=true;

//Language 'ar'=Arabic     'en'=english
$language='ar';

$dollar=1300;

?>