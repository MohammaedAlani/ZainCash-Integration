<?php
ini_set('precision', 15); 
require_once('includes/autoload.php');
use \Firebase\JWT\JWT;

class zain_cash_payment extends WC_Payment_Gateway {

	// Setup our Gateway's id, description and other values
	function __construct() {

		// The global ID for this Payment method
		$this->id = "zain_cash_payment";

		// The Title shown on the top of the Payment Gateways Page next to all the other Payment Gateways
		$this->method_title = __( "Zain Cash Payment", 'zain-cash-payment' );

		// The description for this Payment Gateway, shown on the actual Payment options page on the backend
		$this->method_description = __( "Zain Cash Payment Gateway Plug-in for WooCommerce ", 'zain-cash-payment' );

		// The title to be used for the vertical tabs that can be ordered top to bottom
		$this->title = __( "Zain Cash Payment", 'zain-cash-payment' );

		// If you want to show an image next to the gateway's name on the frontend, enter a URL to an image.
		$this->icon = 'https://zaincash.iq/zain-iq-mfs-style-ce-theme/images/mfs/logo-rtl.png';

		// Bool. Can be set to true if you want payment fields to show on the checkout 
		// if doing a direct integration, which we are doing in this case
		$this->has_fields = false;

		// Supports the default credit card form
		//$this->supports = array( 'default_credit_card_form' );

		// This basically defines your settings which are then loaded with init_settings()
		$this->init_form_fields();

		// After init_settings() is called, you can get the settings and load them into variables, e.g:
		// $this->title = $this->get_option( 'title' );
		$this->init_settings();
		
		// Turn these settings into variables we can use
		foreach ( $this->settings as $setting_key => $value ) {
			$this->$setting_key = $value;
		}
		
		// Lets check for SSL
		add_action( 'admin_notices', array( $this,	'do_ssl_check' ) );
		
		// Save settings
		if ( is_admin() ) {
			// Versions over 2.0
			// Save our administration options. Since we are not going to be doing anything special
			// we have not defined 'process_admin_options' in this class so the method in the parent
			// class will be used instead
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		}	

		add_action( 'woocommerce_api_zain_cash_payment',array( $this, 'check_zc_payment') );



		
	} // End __construct()

	// Build the administration fields for this specific Gateway
	public function init_form_fields() {
		$this->form_fields = array(
		'enabled' => array(
		'title'		=> __( 'Enable / Disable', 'zain-cash-payment' ),
		'label'		=> __( 'Enable this payment gateway', 'zain-cash-payment' ),
		'type'		=> 'checkbox',
		'default'	=> 'no',
		),
		'title' => array(
		'title'		=> __( 'Title', 'zain-cash-payment' ),
		'type'		=> 'text',
		'desc_tip'	=> __( 'Payment title the customer will see during the checkout process.', 'zain-cash-payment' ),
		'default'	=> __( 'Zaincash payment', 'zain-cash-payment' ),
		),
		'description' => array(
		'title'		=> __( 'Description', 'zain-cash-payment' ),
		'type'		=> 'textarea',
		'desc_tip'	=> __( 'Payment description the customer will see during the checkout process.', 'zain-cash-payment' ),
		'default'	=> __( 'Pay using Zaincash payment.', 'zain-cash-payment' ),
		'css'		=> 'max-width:350px;'
		),
		'Merchant_ID' => array(
		'title'		=> __( 'Merchant ID', 'zain-cash-payment' ),
		'type'		=> 'text',
		'desc_tip'	=> __( 'This is the API Merchant ID.', 'zain-cash-payment' ),
		),
		'Api_Secret' => array(
		'title'		=> __( 'Api Secret Key', 'zain-cash-payment' ),
		'type'		=> 'text',
		'desc_tip'	=> __( 'This is Api Secret Key.', 'zain-cash-payment' ),
		),
		
		'msisdn_id' => array(
		'title'		=> __( 'msisdn id(wallet number)', 'zain-cash-payment' ),
		'type'		=> 'text',
		'desc_tip'	=> __( 'This is Api Secret Key.', 'zain-cash-payment' ),
		),
		'redirectUrl' => array(
		'title'		=> __( 'Redirect Url', 'zain-cash-payment' ),
		'type'		=> 'text',
		'desc_tip'	=> __( 'This is for when responce return.', 'zain-cash-payment' ),
		),
		'isdollar' => array(
		'title'		=> __( 'Your store in dollar?', 'zain-cash-payment' ),
		'label'		=> __( 'If website in dollar, check it.', 'zain-cash-payment' ),
		'type'		=> 'checkbox',
		'default'	=> 'no',
		),
		'dollar_conv' => array(
		'title'		=> __( 'Dollar Exchange Rate (write 1300 for example)', 'zain-cash-payment' ),
		'type'		=> 'text',
		'desc_tip'	=> __( 'Dollar price, written like this 1300', 'zain-cash-payment' ),
		),
		'test_enabled' => array(
		'title'		=> __( 'Test credentials', 'zain-cash-payment' ),
		'label'		=> __( 'Enable test payment gateway', 'zain-cash-payment' ),
		'type'		=> 'checkbox',
		'default'	=> 'no',
		)
		);		
	}
	
	// Submit payment and handle response
	public function process_payment( $order_id ) {

		global $woocommerce;
		//Getting Settings
		$Api_Secret=$this->Api_Secret;
		$MERCHANT_ID = $this->Merchant_ID;
		$Api_NUMBER = $this->Api_Secret;
		$msisdn_id=$this->msisdn_id;
		$dollar_p=$this->dollar_conv;
		$isdollar=$this->isdollar;
		$dollary=(int) $dollar_p;
		$order          = wc_get_order( $order_id );
		$customer_order = new WC_Order( $order_id );
		
		
		$iaaa=time();
		$iexp=$iaaa+60*60*4;


		//Checking dollar or dinar SETTING
		if($isdollar=='yes'){$factor=$dollary;}else{$factor=1;}
		
		//Building redirect url
        $redirect_url = home_url( '/' ).'wc-api/'.get_class( $this );

		//building token
		$data = [
		'amount'  => intval($customer_order->order_total*$factor),        
		'serviceType'  => "WordPress Cart",          
		'msisdn'  => (double) $msisdn_id,  
		'orderId'  => intval($order_id),
		'redirectUrl'  => $redirect_url,
		'iat'  => $iaaa,
		'exp'  => $iexp
		];

		
		
		//Encoding Token
		$token_re = JWT::encode(
		$data,      //Data to be encoded in the JWT
		$Api_Secret ,'HS256'
		);
		
		//Check if test or production mode
		if($this->test_enabled == 'yes'){
			$tUrl = 'https://test.zaincash.iq/transaction/init';
			$rUrl = 'https://test.zaincash.iq/transaction/pay?id=';
		}else{
			$tUrl = 'https://api.zaincash.iq/transaction/init';
			$rUrl = 'https://api.zaincash.iq/transaction/pay?id=';
		}
		
		
		//POSTing data to API
		$data_to_post = array();
		$data_to_post['token'] = urlencode($token_re);
		$data_to_post['merchantId'] = $MERCHANT_ID;
		$data_to_post['lang'] = "en";
		$options = array(
		'http' => array(
		'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
		'method'  => 'POST',
		'content' => http_build_query($data_to_post),
		),
		);
		$context  = stream_context_create($options);
		$response= file_get_contents($tUrl, false, $context);
		
		

		//Parsing response
		$array = json_decode($response, true);
		$id = $array['id'];
		return array(
		'result'   => 'success',
		'redirect' => $rUrl.$id
		);

	}
	
	public function check_zc_payment (){
		global $woocommerce;
		
		if (isset ($_GET['token'])){
			
			$tokeno=$_GET['token'];
			//Decoding token
			$orderjson= JWT::decode($tokeno, $this->Api_Secret, array('HS256'));
			$orderjson=(array) $orderjson;
			$orderid=$orderjson['orderid'];
			$order    = new WC_Order( $orderid );
			
			//Checking status
			//If success
			if (strtolower($orderjson['status'])=='success'){
				$order->payment_complete();
				$order->update_status('processing');
				$order->reduce_order_stock();
				$woocommerce->cart->empty_cart();
                $order->add_order_note('Paid successfully');
				wp_redirect($this->get_return_url( $order ));
				return;
			}
			
			//If failed
			if ($orderjson['status']=='failed'){
				$order -> update_status('failed');
				$order -> add_order_note($orderjson['msg']);
				wp_redirect($order->get_cancel_order_url());
				return;
			}
			
			
		}
		
		wp_redirect(home_url( '/' ).'cart/');
		return;
		
	}
	
	// Validate fields
	public function validate_fields() {
		return true;
	}
	
	// Check if we are forcing SSL on checkout pages
	// Custom function not required by the Gateway
	public function do_ssl_check() {
		if( $this->enabled == "yes" ) {
			if( get_option( 'woocommerce_force_ssl_checkout' ) == "no" ) {
				echo "<div class=\"error\"><p>". sprintf( __( "<strong>%s</strong> is enabled and WooCommerce is not forcing the SSL certificate on your checkout page. Please ensure that you have a valid SSL certificate and that you are <a href=\"%s\">forcing the checkout pages to be secured.</a>" ), $this->method_title, admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ) ."</p></div>";	
			}
		}		
	}

} // End of SPYR_AuthorizeNet_AIM