﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



public partial class _Default : Page
{




    //Credentials
    string merchantid = "57f3a0635a726a48ee912866";
    string secret = "1zaza5a444a6e8723asd123asd123sfeasdase12312davwqf123123xc2ego";
    double msisdn = 9647800624733;
    string lang = "ar";  // "ar"   or    "en"
    string service_type = "Testing... Put you service type here like: Books";
    string redirection_url = "https://chanbar.com/testing.php"; //the url that will be redirected to, after completion of payment
    int dollar_exchange_rate = 1300;



    public string generate_zaincash_url(int orderid, float amount, bool isdollar)
    {
        //Change currency to dollar if required
        int new_amount;
        if (isdollar) { new_amount = (int)(amount * dollar_exchange_rate); } else { new_amount = (int)amount; }

        //Setting expiration of token
        Int32 iat = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
        Int32 exp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds + 60 * 60 * 4;



        //Generate the data array
        IDictionary<string, object> dataarray = new Dictionary<string, object>();
        dataarray.Add("amount",new_amount);
        dataarray.Add("serviceType",service_type);
        dataarray.Add("msisdn",msisdn);
        dataarray.Add("orderId",orderid);
        dataarray.Add("redirectUrl",redirection_url);
        dataarray.Add("iat",iat);
        dataarray.Add("exp",exp);


        //Generating token
        string token = Jose.JWT.Encode(dataarray, System.Text.Encoding.ASCII.GetBytes(secret), Jose.JwsAlgorithm.HS256);


        //Posting token to ZainCash API to generate Transaction ID
        var httpclient = new System.Net.WebClient();
        var data_to_post = new System.Collections.Specialized.NameValueCollection();
        data_to_post["token"] = token;
        data_to_post["merchantId"] = merchantid;
        data_to_post["lang"] = lang;

        string response = System.Text.Encoding.ASCII.GetString(httpclient.UploadValues("https://api.zaincash.iq/transaction/init", "POST", data_to_post));

        //Parse JSON response to Object
        var jsona=Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(response);

        //Return final URL
        return "https://api.zaincash.iq/transaction/pay?id=" + (string)jsona.id;
    }


	
	
	
	
	
    public Dictionary<string,string> after_redirection(string token)
    {
        //Convert token to json, then to object
        var jsona_res=Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(Jose.JWT.Decode(token, System.Text.Encoding.ASCII.GetBytes(secret)));

        //Generating response array
        Dictionary<string, string> final = new Dictionary<string, string>();
        final.Add("status", (string)jsona_res.status);
        if (jsona_res.status == "failed") { final.Add("msg", (string)jsona_res.msg); }

        return final;
    }




	
	
	
	
	
	
    protected void Page_Load(object sender, EventArgs e)
    {

        //HOW TO GENERATE URL (must be included in REQUEST PAGE)
        var url=generate_zaincash_url(1, 23.5f, true);

        //-----------------------------------------------------------------

        //HOW TO GET STATUS OF TRANSACTION AFTER REDIRECTION (Must be included in REDIRECTION PAGE)

        //Example of token
        var sdf = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdGF0dXMiOiJmYWlsZWQiLCJtc2ciOiJJbnZhbGlkIGNyZWRlbnRpYWxzIGZvciByZXF1ZXN0ZXIiLCJvcmRlcmlkIjoiMSIsImlkIjoiNTg1ZGM3Njc5MjE0YzkxZjMyZTAyOWFhIiwiaWF0IjoxNDgyNTQxMTE2LCJleHAiOjE0ODI1NDQ3MTZ9.Q8Gr9Lxfd_AQ-22_xMrHgOqgmZ5B6j7AlOE6K-mDT7M";

        var result = after_redirection(sdf);
        if (result["status"] == "success")
        {
            //Success transaction
        }

        if (result["status"] == "failed")
        {
            //Failed transaction
            //Reason
            var reason = result["msg"];
        }




    }
}