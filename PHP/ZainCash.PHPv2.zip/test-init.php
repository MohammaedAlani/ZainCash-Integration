<?php
/**
 * ZainCash PHP SDK
 * @version 1.0.0
 *
 * @package ZainCash
 * @copyright 2014-2017 All Right Reserved Iraq Wallet
 *
 * @author Alhasan Ahmed Al-Nasiry <alhasan.nasiry@gmail.com>
 */

require_once __DIR__ . '/vendor/autoload.php'; // Autoload files using Composer autoload

use ZainCashIQ\ZainCash;
use Dotenv\Dotenv;

$dotenv = new Dotenv(__DIR__);
$dotenv->load();


//echo JWT::decode("asdasdas.dasdsadasd.asda");
try {
  $zc = new ZainCash([
    'msisdn' => $_ENV['ZC_MSISDN'],
    'secret' => $_ENV['ZC_SECRET'],
    'merchantid'=> $_ENV['ZC_MERCHANTID'],
    'production_cred'=> ( $_ENV['ZC_ENV_PRODUCTION'] === 'true' ),
    'language'=>'en', // 'en' or 'ar'
    'redirection_url'=>'https://example.com/redirect.php'

  ]);
  $zc->charge(
    1000,
    'Product purchase or something',
    'Order_00001'
  );

} catch (Exception $e) {
    echo $e->getMessage();
}
