<?php
class ControllerPaymentZainCash extends Controller {
  private $error = array();
 
  public function index() {
    $this->language->load('payment/zaincash');
    $this->document->setTitle('اعدادات زين كاش للدفع الالكتروني');
    $this->load->model('setting/setting');
 
    if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
      $this->model_setting_setting->editSetting('zaincash', $this->request->post);
      $this->session->data['success'] = 'تم الحفظ.';
      $this->redirect($this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'));
    }
 
    $this->data['heading_title'] = $this->language->get('heading_title');
    $this->data['entry_text_merchantid'] = $this->language->get('text_merchantid');
    $this->data['entry_text_merchantsecret'] = $this->language->get('text_merchantsecret');
    $this->data['entry_text_merchantmsisdn'] = $this->language->get('text_merchantmsisdn');
    $this->data['entry_text_isdollar'] = $this->language->get('text_isdollar');
    $this->data['entry_text_dollarprice'] = $this->language->get('text_dollarprice');
    $this->data['entry_text_testcred'] = $this->language->get('text_testcred');
    $this->data['button_save'] = $this->language->get('text_button_save');
    $this->data['button_cancel'] = $this->language->get('text_button_cancel');
    $this->data['entry_order_status'] = $this->language->get('entry_order_status');
    $this->data['text_enabled'] = $this->language->get('text_enabled');
    $this->data['text_disabled'] = $this->language->get('text_disabled');
    $this->data['entry_status'] = $this->language->get('entry_status');
 
    $this->data['action'] = $this->url->link('payment/zaincash', 'token=' . $this->session->data['token'], 'SSL');
    $this->data['cancel'] = $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL');
 
    if (isset($this->request->post['text_merchantid'])) {
      $this->data['text_merchantid'] = $this->request->post['text_merchantid'];
    } else {
      $this->data['text_merchantid'] = $this->config->get('text_merchantid');
    }
        
    if (isset($this->request->post['text_merchantsecret'])) {
      $this->data['text_merchantsecret'] = $this->request->post['text_merchantsecret'];
    } else {
      $this->data['text_merchantsecret'] = $this->config->get('text_merchantsecret');
    }
        
    if (isset($this->request->post['text_merchantmsisdn'])) {
      $this->data['text_merchantmsisdn'] = $this->request->post['text_merchantmsisdn'];
    } else {
      $this->data['text_merchantmsisdn'] = $this->config->get('text_merchantmsisdn');
    }
        
    if (isset($this->request->post['text_isdollar'])) {
      $this->data['text_isdollar'] = $this->request->post['text_isdollar'];
    } else {
      $this->data['text_isdollar'] = $this->config->get('text_isdollar');
    }
        
    if (isset($this->request->post['text_dollarprice'])) {
      $this->data['text_dollarprice'] = $this->request->post['text_dollarprice'];
    } else {
      $this->data['text_dollarprice'] = $this->config->get('text_dollarprice');
    }
        
    if (isset($this->request->post['text_testcred'])) {
      $this->data['text_testcred'] = $this->request->post['text_testcred'];
    } else {
      $this->data['text_testcred'] = $this->config->get('text_testcred');
    }
        
            
    if (isset($this->request->post['zaincash_status'])) {
      $this->data['zaincash_status'] = $this->request->post['zaincash_status'];
    } else {
      $this->data['zaincash_status'] = $this->config->get('zaincash_status');
    }
        
 
    $this->load->model('localisation/order_status');
    $this->data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
    $this->template = 'payment/zaincash.tpl';
            
    $this->children = array(
      'common/header',
      'common/footer'
    );
 
    $this->response->setOutput($this->render());
  }
}
?>