<?php

$_['heading_title'] = 'Zain Cash Payment Gateway';
 
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_zaincash'] = '<a href="http://www.zaincash.iq/" target="_blank"><img src="view/image/payment/zaincash.png" alt="Zain Cash" title="Zain Cash" style="border: 1px solid #EEEEEE;" /></a>';


$_['text_merchantid'] = 'Merchant ID';
$_['text_merchantsecret'] = 'Merchant Secret';
$_['text_merchantmsisdn'] = 'Merchant MSISDN';
$_['text_isdollar'] = 'هل عملة المتجر بالدولار؟ ( اكتب 1 اذا بالدولار، و 0 اذا بالدينار )';
$_['text_dollarprice'] = 'سعر صرف الدولار (كمثال اكتب 1300)';
$_['text_testcred'] = 'الوضع التجريبي؟ (اكتب 1 للوضع التجريبي، و 0 للوضع الحي)';
 
$_['entry_status'] = 'الحالة:';
$_['entry_order_status'] = 'تسلسل الفرز:';
 
$_['text_button_save'] = 'حفظ';
$_['text_button_cancel'] = 'الغاء الامر';


?>