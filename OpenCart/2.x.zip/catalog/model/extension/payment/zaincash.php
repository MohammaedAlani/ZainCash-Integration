<?php
class ModelExtensionPaymentZainCash extends Model {
  public function getMethod($address, $total) {
    $this->load->language('extension/payment/zaincash');
  
    $method_data = array(
      'code'     => 'zaincash',
      'title'    => $this->language->get('text_title'),
	  'terms'	=> '',
      'sort_order' => $this->config->get('zaincash_sort_order')
    );
  
    return $method_data;
  }
}