<?php
ini_set('precision', 15); 
require_once('includes/autoload.php');
use \Firebase\JWT\JWT;



class ControllerExtensionPaymentZainCash extends Controller {
	public function index() {
		$this->language->load('extension/payment/zaincash');
		$data['button_confirm'] = $this->language->get('button_confirm');
		$this->load->model('checkout/order');
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		
		$data['zaincash_merchantid'] = trim($this->config->get('zaincash_merchantid')); 
		$data['zaincash_merchantsecret'] = trim($this->config->get('zaincash_merchantsecret')); 
		$data['zaincash_merchantmsisdn'] = trim($this->config->get('zaincash_merchantmsisdn')); 
		$data['zaincash_isdollar'] = trim($this->config->get('zaincash_isdollar')); 
		$data['zaincash_dollarprice'] = trim($this->config->get('zaincash_dollarprice')); 
		$data['zaincash_testcred'] = trim($this->config->get('zaincash_testcred')); 
		$data['orderid'] = date('His') . $this->session->data['order_id'];
		$data['callbackurl'] = $this->url->link('extension/payment/zaincash/callback', '', true);

		
		//Checking dollar or dinar SETTING
		if($data['zaincash_isdollar']=='1'){$factor=intval($data['zaincash_dollarprice']);}else{$factor=1;}
		
		//Building redirect url
		$redirect_url = $data['callbackurl'].'&t=';

		//building token
		$iaaa=time();
		$iexp=$iaaa+60*60*4;

		$datajson = [
		'amount'  => intval($order_info['total']*$factor),        
		'serviceType'  => "WordPress Cart",          
		'msisdn'  => (double) $data['zaincash_merchantmsisdn'],  
		'orderId'  => intval($this->session->data['order_id']),
		'redirectUrl'  => $redirect_url,
		'iat'  => $iaaa,
		'exp'  => $iexp
		];

		
		
		//Encoding Token
		$token_re = JWT::encode(
		$datajson,      //Data to be encoded in the JWT
		$data['zaincash_merchantsecret'] ,'HS256'
		);
		
		//Check if test or production mode
		if($data['zaincash_testcred'] == '1'){
			$tUrl = 'https://test.zaincash.iq/transaction/init';
			$rUrl = 'https://test.zaincash.iq/transaction/pay?id=';
		}else{
			$tUrl = 'https://api.zaincash.iq/transaction/init';
			$rUrl = 'https://api.zaincash.iq/transaction/pay?id=';
		}
		
		
		//POSTing data to API
		$data_to_post = array();
		$data_to_post['token'] = urlencode($token_re);
		$data_to_post['merchantId'] = $data['zaincash_merchantid'];
		$data_to_post['lang'] = "ar";
		$options = array(
		'http' => array(
		'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
		'method'  => 'POST',
		'content' => http_build_query($data_to_post),
		),
		);
		$context  = stream_context_create($options);
		$response= file_get_contents($tUrl, false, $context);
		
		
		//Parsing response
		$array = json_decode($response, true);
		$idddd = $array['id'];

		
		
		
		
		$data['action'] = 'https://api.zaincash.iq/transaction/pay?id='.$idddd;

		if ($order_info) {
			$data['orderdate'] = date('YmdHis');
			$data['currency'] = $order_info['currency_code'];
			$data['orderamount'] = $this->currency->format($order_info['total'], $data['currency'] , false, false);
			
			

			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/extension/payment/zaincash.tpl')){
				$this->template = $this->config->get('config_template') . '/template/payment/zaincash.tpl';
			} else {
				$this->template = 'default/template/payment/zaincash.tpl';
			}
			
			return $this->load->view('extension/payment/zaincash', $data);


		}
	}

	public function callback() {
		
		
		if (isset($this->request->get['ampt'])) {

			$tokeno=str_replace('?token=','',$this->request->get['ampt']);
			if($tokeno!=''){
				$orderjson= JWT::decode($tokeno, $this->config->get('zaincash_merchantsecret'), array('HS256'));
				$orderjson=(array) $orderjson;
				
				$orderid=$orderjson['orderid'];
				
				$order_id = $orderid;


				
				$this->load->model('checkout/order');
				$order_info = $this->model_checkout_order->getOrder($order_id);

				
				if ($orderjson['status']=='success'){
					$this->model_checkout_order->addOrderHistory($order_id, 2);
					header('Location: '.   $this->url->link('checkout/success', '', true));
					
					

				} 
				if ($orderjson['status']=='failed'){
					$data3=array();
					$data3['text_failure']='فشل في الدفع';
					$data3['text_failure_msg']=$orderjson['msg'];
					$this->response->setOutput($this->load->view('extension/payment/zaincash_failed', $data3));

				} 
				
			} else {header ('Location: ./');}
			
		}
		


	}
}
?>