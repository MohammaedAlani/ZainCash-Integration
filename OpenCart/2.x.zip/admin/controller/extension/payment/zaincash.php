<?php
class ControllerExtensionPaymentZainCash extends Controller {
	private $error = array();

	public function index() {
		$this->language->load('extension/payment/zaincash');
		$this->document->setTitle('اعدادات زين كاش للدفع الالكتروني');
		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
			$this->model_setting_setting->editSetting('zaincash', $this->request->post);

			$this->session->data['success'] = 'تم الحفظ.';
			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true));
		}

		$data['heading_title'] = $this->language->get('heading_title');
		$data['entry_text_merchantid'] = $this->language->get('text_merchantid');
		$data['entry_text_merchantsecret'] = $this->language->get('text_merchantsecret');
		$data['entry_text_merchantmsisdn'] = $this->language->get('text_merchantmsisdn');
		$data['entry_text_isdollar'] = $this->language->get('text_isdollar');
		$data['entry_text_dollarprice'] = $this->language->get('text_dollarprice');
		$data['entry_text_testcred'] = $this->language->get('text_testcred');
		$data['button_save'] = $this->language->get('text_button_save');
		$data['button_cancel'] = $this->language->get('text_button_cancel');
		$data['entry_order_status'] = $this->language->get('entry_order_status');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['text_edit'] = $this->language->get('text_edit');

		$data['action'] = $this->url->link('extension/payment/zaincash', 'token=' . $this->session->data['token'], 'SSL');
		$data['cancel'] = $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL');
		$data['entry_sort_order'] = $this->language->get('entry_sort_order');

		if (isset($this->request->post['zaincash_merchantid'])) {
			$data['zaincash_merchantid'] = $this->request->post['zaincash_merchantid'];
		} else {
			$data['zaincash_merchantid'] = $this->config->get('zaincash_merchantid');
		}

		if (isset($this->request->post['zaincash_merchantsecret'])) {
			$data['zaincash_merchantsecret'] = $this->request->post['zaincash_merchantsecret'];
		} else {
			$data['zaincash_merchantsecret'] = $this->config->get('zaincash_merchantsecret');
		}
		
		if (isset($this->request->post['zaincash_merchantmsisdn'])) {
			$data['zaincash_merchantmsisdn'] = $this->request->post['zaincash_merchantmsisdn'];
		} else {
			$data['zaincash_merchantmsisdn'] = $this->config->get('zaincash_merchantmsisdn');
		}
		
		if (isset($this->request->post['zaincash_isdollar'])) {
			$data['zaincash_isdollar'] = $this->request->post['zaincash_isdollar'];
		} else {
			$data['zaincash_isdollar'] = $this->config->get('zaincash_isdollar');
		}
		
		if (isset($this->request->post['zaincash_dollarprice'])) {
			$data['zaincash_dollarprice'] = $this->request->post['zaincash_dollarprice'];
		} else {
			$data['zaincash_dollarprice'] = $this->config->get('zaincash_dollarprice');
		}
		
		if (isset($this->request->post['zaincash_testcred'])) {
			$data['zaincash_testcred'] = $this->request->post['zaincash_testcred'];
		} else {
			$data['zaincash_testcred'] = $this->config->get('zaincash_testcred');
		}
		
		
		if (isset($this->request->post['zaincash_status'])) {
			$data['zaincash_status'] = $this->request->post['zaincash_status'];
		} else {
			$data['zaincash_status'] = $this->config->get('zaincash_status');
		}
		if (isset($this->request->post['zaincash_sort_order'])) {
			$data['zaincash_sort_order'] = $this->request->post['zaincash_sort_order'];
		} else {
			$data['zaincash_sort_order'] = $this->config->get('zaincash_sort_order');
		}


		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
		'text' => $this->language->get('text_home'),
		'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
		'text' => $this->language->get('text_extension'),
		'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
		'text' => $this->language->get('heading_title'),
		'href' => $this->url->link('extension/payment/zaincash', 'token=' . $this->session->data['token'], true)
		);
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}



		$this->load->model('localisation/order_status');
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		$this->template = 'extension/payment/zaincash.tpl';
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/payment/zaincash', $data));

		//$this->response->setOutput($this->render());
	}
}
?>