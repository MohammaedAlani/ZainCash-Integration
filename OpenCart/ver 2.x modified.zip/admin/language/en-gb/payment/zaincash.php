<?php

$_['heading_title'] = 'زين كاش للدفع الالكتروني';
 
$_['text_enabled'] = 'مفعل';
$_['text_disabled'] = 'غير مفعل';
 
$_['text_extension']				 = 'الاضافات';
$_['text_zaincash']				 = '<a target="_BLANK" href="http://www.zaincash.iq"><img src="view/image/payment/zaincash.png" alt="Zain Cash" title="Zain Cash" style="border: 1px solid #EEEEEE;" /></a>';

$_['text_merchantid'] = 'Merchant ID';
$_['text_merchantsecret'] = 'Merchant Secret';
$_['text_merchantmsisdn'] = 'Merchant MSISDN';
$_['text_isdollar'] = 'هل عملة المتجر بالدولار؟ ( اكتب 1 اذا بالدولار، و 0 اذا بالدينار )';
$_['text_dollarprice'] = 'سعر صرف الدولار (كمثال اكتب 1300)';
$_['text_testcred'] = 'الوضع التجريبي؟ (اكتب 1 للوضع التجريبي، و 0 للوضع الحي)';
 
$_['entry_status'] = 'الحالة:';
 $_['entry_sort_order']				 = 'تسلسل الفرز';

$_['text_button_save'] = 'حفظ';
$_['text_button_cancel'] = 'الغاء الامر';
$_['text_edit']                      = 'تعديل اعدادات زين كاش';


?>