<?php
/*
Plugin Name: Easy Digital Downloads - ZainCash Payment Gateway
Plugin URL: https://zaincash.iq
Description: ZainCash Payment Gateway for Easy Digital Downloads
Version: 1.0
Author: Dr. Mustafa Younis
Author URI: http://mstfyounis.com
*/
require_once('includes/autoload.php');
use \Firebase\JWT\JWT;

// registers the gateway
function zain_cash_register_gateway( $gateways ) {
	$gateways['zaincash'] = array( 'admin_label' => 'ZainCash Gateway', 'checkout_label' => __( 'ZainCash Gateway', 'zain_cash' ) );
	return $gateways;
}
add_filter( 'edd_payment_gateways', 'zain_cash_register_gateway' );


// Remove this if you want a credit card form
add_action( 'edd_zaincash_cc_form', '__return_false' );


// processes the payment
function zain_cash_process_payment( $purchase_data ) {

	global $edd_options;
	

	// check for any stored errors
	$errors = edd_get_errors();
	if ( ! $errors ) {

		$purchase_summary = edd_get_purchase_summary( $purchase_data );

		/****************************************
		* setup the payment details to be stored
		****************************************/

		$payment = array(
		'price'        => $purchase_data['price'],
		'date'         => $purchase_data['date'],
		'user_email'   => $purchase_data['user_email'],
		'purchase_key' => $purchase_data['purchase_key'],
		'currency'     => $edd_options['currency'],
		'downloads'    => $purchase_data['downloads'],
		'cart_details' => $purchase_data['cart_details'],
		'user_info'    => $purchase_data['user_info'],
		'status'       => 'pending'
		);

		// record the pending payment
		$payment = edd_insert_payment( $payment );

		$redirection_url =  home_url( '?edd-listener=zaincash&token=' ) ;
		$price2=0;
		//Getting price and exchange rate
		if (edd_get_option('zaincash_isdollar')=='2'){
			$price2=$purchase_data['price']*intval(edd_get_option('zaincash_dollar_rate'));
		} else {
			$price2=$purchase_data['price'];
		}
		
		
		//building data
		$data = [
		'amount'  => intval($price2),        
		'serviceType'  => 'EDD',          
		'msisdn'  => intval(edd_get_option('zaincash_msisdn')),  
		'orderId'  => $payment,
		'redirectUrl'  => $redirection_url,
		'iat'  => time(),
		'exp'  => time()+60*60*4
		];

		//Encoding Token
		$newtoken = JWT::encode(
		$data,      //Data to be encoded in the JWT
		edd_get_option('zaincash_secret') ,'HS256'
		);



		//Check if test or production mode
		if(edd_get_option('zaincash_testingmode')=='1'){
			$tUrl = 'https://api.zaincash.iq/transaction/init';
			$rUrl = 'https://api.zaincash.iq/transaction/pay?id=';
		}else{
			$tUrl = 'https://test.zaincash.iq/transaction/init';
			$rUrl = 'https://test.zaincash.iq/transaction/pay?id=';
		}


		//POSTing data to ZainCash API
		$data_to_post = array();
		$data_to_post['token'] = urlencode($newtoken);
		$data_to_post['merchantId'] = edd_get_option('zaincash_merchant_id');
		$data_to_post['lang'] = $language;
		
		$response=wp_remote_post($tUrl,array(
		'method' => 'POST',
		'timeout' => 45,
		'redirection' => 5,
		'httpversion' => '1.0',
		'blocking' => true,
		'headers' => array(),
		'body' => $data_to_post,
		'cookies' => array()
		));
		$response= $response['body'];
		
		//Parsing response
		$array = json_decode($response, true);
		$transaction_id = $array['id'];
		$newurl=$rUrl.$transaction_id;
		header('Location: '.$newurl);


		exit();
	}
}
add_action( 'edd_gateway_zaincash', 'zain_cash_process_payment' );

function edd_listen_for_zaincash_ipn() {

	//ZainCash IPN
	if ( isset( $_GET['edd-listener'] ) && $_GET['edd-listener'] == 'zaincash' ) {
		//After redirection
		
		//var_dump($_GET);
		//exit();
		if(isset($_GET['amptoken'])){
			$token=str_replace('?token=','',$_GET['amptoken']);
			if($token!=''){
				//you can decode the token by this PHP code:
				$result= JWT::decode($token, edd_get_option('zaincash_secret'), array('HS256'));
				$result= (array) $result;
				

				//And to check for status of the transaction, use $result['status'], like this:
				if ($result['status']=='success'){
					// once a transaction is successful, set the purchase to complete
					edd_update_payment_status( $result['orderid'], 'complete' );

					// record transaction ID, or any other notes you need
					edd_insert_payment_note( $result['orderid'], 'ZainCash' );

					// go to the success page
					edd_send_to_success_page();

				}
				if ($result['status']=='failed'){
					$reason=$result['msg'];
					echo '<h2>حدث خطأ اثناء عملية الدفع</h2><h3>'.$reason.'</h3><a href="./">الرجوع الى الموقع</a>';
					exit();

				}
			}
			
			
			
		}
		
	}
}
add_action( 'init', 'edd_listen_for_zaincash_ipn' );
//Developed by Dr. Mustafa Younis
// adds the settings to the Payment Gateways section
function zain_cash_add_settings( $settings ) {

	$zaincash_gateway_settings = array(
	array(
	'id' => 'zaincash_gateway_settings',
	'name' => '<strong>' . __( 'Zain Cash Gateway Settings', 'zain_cash' ) . '</strong>',
	'desc' => __( 'Configure the gateway settings', 'zain_cash' ),
	'type' => 'header'
	),
	array(
	'id' => 'zaincash_msisdn',
	'name' => __( 'MSISDN', 'zain_cash' ),
	'desc' => __( 'MSISDN of merchant', 'zain_cash' ),
	'type' => 'text',
	'size' => 'regular'
	),
	array(
	'id' => 'zaincash_merchant_id',
	'name' => __( 'Merchant ID', 'zain_cash' ),
	'desc' => __( 'Merchant ID', 'zain_cash' ),
	'type' => 'text',
	'size' => 'regular'
	),
	array(
	'id' => 'zaincash_secret',
	'name' => __( 'Secret', 'zain_cash' ),
	'desc' => __( 'Merchant Secret', 'zain_cash' ),
	'type' => 'text',
	'size' => 'regular'
	),
	array(
	'id' => 'zaincash_isdollar',
	'name' => __( 'are prices in dollar?', 'zain_cash' ),
	'desc' => __( 'if in dollar, write 2, if in Iraqi Dinar, write 1', 'zain_cash' ),
	'type' => 'text',
	'size' => 'regular'
	),
	array(
	'id' => 'zaincash_dollar_rate',
	'name' => __( 'Dollar-Dinar exchange rate', 'zain_cash' ),
	'desc' => __( 'For example, write 1300, or your preferred rate', 'zain_cash' ),
	'type' => 'text',
	'size' => 'regular'
	),
	array(
	'id' => 'zaincash_testingmode',
	'name' => __( 'Use test mode?', 'zain_cash' ),
	'desc' => __( 'Write 2 to use test mode, write 1 for production mode', 'zain_cash' ),
	'type' => 'text',
	'size' => 'regular'
	)
	);

	return array_merge( $settings, $zaincash_gateway_settings );
}
add_filter( 'edd_settings_gateways', 'zain_cash_add_settings' );
